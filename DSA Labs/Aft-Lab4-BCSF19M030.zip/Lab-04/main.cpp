// Name          Kamran Moazim
// Roll Number   BCS-F19-M-030
// Section       BIT-F20-Afternoon

#include<iostream>
#include<fstream>

#include"class.cpp"

using namespace std;


void driverProgram(){

    string fileName="";
    ifstream fs;


    cout<<"Enter name of the input file : ";
    getline(cin, fileName);

    fs.open(fileName, ios::in);

    while(fs.fail()){
        cout<<"File could not be opened!"<<endl;
        cout<<"Please Enter name of the input file again : ";
        getline(cin, fileName);

        fs.open(fileName, ios::in);
    }

    PacketManager packetManagerObject(fs);

    
    cout<<"Packets originally read from the file are:"<<endl;
    packetManagerObject.displayPackets();


    packetManagerObject.extractMessage();
    cout<<"The order of packets after extracting the message: "<<endl;
    packetManagerObject.displayPackets();

    cout<<"The extracted message is: "<<endl;
    packetManagerObject.displayMessage();

}



int main(){

    driverProgram();

    return 0;

}
